import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  date: any;

  constructor() {}

  ngOnInit(): void {
    setInterval(() => {
      this.date = moment(new Date());
    }, 1000);
  }
}
