import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  ValidatorFn,
} from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../../../shared/data.services';
import { config } from 'rxjs';

@Component({
  selector: 'app-task-config',
  templateUrl: './task-config.component.html',
  styleUrls: ['./task-config.component.scss'],
})
export class TaskConfigComponent implements OnInit {
  form: FormGroup = new FormGroup({
    taskId: new FormControl(''),
    titlle: new FormControl(''),
    assignDate: new FormControl(''),
    dueDate: new FormControl(''),
    description: new FormControl(''),
    status: new FormControl(false),
  });
  submitted = false;
  action: any;
  listView: boolean = false;
  gridView: boolean = true;
  taskDetails: any = [];
  taskId: any;
  title: any;
  description: any;
  assignDate: any;
  assignTo: any;
  dueDate: any;
  openTaskId: any;
  status: any;
  taskData = 'pending';

  constructor(
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private datePipe: DatePipe,
    private dataService: DataService
  ) {}
  ngOnInit(): void {
    this.form = this.formBuilder.group({
      taskId: ['', Validators.required],
      title: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(20),
        ],
      ],

      assignDate: ['', Validators.required],
      description: ['', Validators.required],
      assignTo: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(20),
        ],
      ],
      dueDate: ['', Validators.required],
      status: ['', Validators.required],
    });
    this.getTask();
  }

  getTask() {
    this.dataService.get('config/getTask').subscribe((res: any) => {
      this.taskDetails = res['data'];
      console.log(res, 'resresres');
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  updateDueDateMin(selectedDate: any) {
    const today = new Date();
    const selectedDateObj = new Date(selectedDate.target.value);

    // If the selected date is in the past, set it to today
    if (selectedDateObj < today) {
      this.form
        .get('assignDate')
        ?.setValue(this.datePipe.transform(today, 'yyyy-MM-dd'));
    }
    console.log(selectedDateObj, selectedDate, 'selectedDateObj');

    // Set the minimum due date to the selected date
    this.form.get('dueDate')?.setValue(selectedDate);
  }
  grid() {
    this.gridView = true;
    this.listView = false;
  }
  list() {
    this.gridView = false;
    this.listView = true;
  }

  openModal(template: any, data: any, id: any, act: any) {
    this.action = act;
    this.openTaskId = id;
    if (this.action == 'edit') {
      this.taskId = data.taskId;
      this.title = data.title;
      this.description = data.description;
      this.assignDate = data.assignDate;
      this.assignTo = data.assignTo;
      this.dueDate = data.dueDate;
      this.status = data.status;
      console.log(data, 'edit');
    } else if (this.action == 'add') {
      this.taskId = '';
      this.title = '';
      this.description = '';
      this.assignDate = '';
      this.assignTo = '';
      this.dueDate = '';
    }
    this.modalService.open(template, {
      backdrop: 'static',
      keyboard: false,
      centered: true,
      size: 'lg',
    });
  }

  cancel() {
    this.form.reset();
    this.modalService.dismissAll();
  }

  delete(data: any) {
    console.log(data);
    this.dataService
      .delete('config/deleteTask/' + this.openTaskId)
      .subscribe((res) => {
        this.getTask();
        this.modalService.dismissAll();
      });
  }

  statusData(data: any, $event: any) {
    console.log(data);
    if (data == 'pending') {
      this.taskData = data;
    } else {
      this.taskData = 'true';
    }
    let clickedElement = $event.target || $event.srcElement;

    if (clickedElement.nodeName === 'BUTTON') {
      let isCertainButtonAlreadyActive =
        clickedElement.parentElement.querySelector('.active');
      // if a Button already has Class: .active
      if (isCertainButtonAlreadyActive) {
        isCertainButtonAlreadyActive.classList.remove('active');
      }

      clickedElement.className += ' active';
    }
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    if (this.action == 'add') {
      this.dataService
        .post('config/addTask', this.form.value)
        .subscribe((res) => {
          this.getTask();
          console.log(res);
        });
    } else {
      this.dataService
        .put('config/updateTask/' + this.openTaskId, this.form.value)
        .subscribe((res) => {
          this.getTask();
          console.log(res, 'update');
        });
    }
    this.cancel();
  }
}
