import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskConfigComponent } from './task-config.component';
import { DatePipe } from '@angular/common';
// import {HttpClientTestingModule,HttpTestingController} from '@angular/common/http/testing'
import { HttpClientModule } from '@angular/common/http';
describe('TaskConfigComponent', () => {
  let component: TaskConfigComponent;
  let fixture: ComponentFixture<TaskConfigComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TaskConfigComponent],
      imports: [HttpClientModule],
      providers: [DatePipe],
    });
    fixture = TestBed.createComponent(TaskConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
