import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent {
  constructor(private router: Router) {}
  gradients = [
    {
      name: 'Nimvelo',
      colors: ['#314755', '#26a0da'],
    },
  ];
  ngOnInit(): void {}
  getStarted() {
    this.router.navigate(['task/config']);
  }
}
