export const environment = {
  url: 'http://localhost:4000/',
  production: false,
};
