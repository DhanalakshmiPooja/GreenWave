export const environment = {
  url: 'http://localhost:8000/',
  //   url: `http://${location.hostname}:3000/`,
  production: false,
};
